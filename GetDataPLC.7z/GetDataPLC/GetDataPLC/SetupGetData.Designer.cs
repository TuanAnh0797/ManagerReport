﻿namespace GetDataPLC
{
    partial class SetupGetData
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txb_namefunction = new System.Windows.Forms.TextBox();
            this.txb_ipaddress = new System.Windows.Forms.TextBox();
            this.txb_portnumber = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_add = new System.Windows.Forms.Button();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.btn_update = new System.Windows.Forms.Button();
            this.dtg_dataconfig = new System.Windows.Forms.DataGridView();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txb_NameDeviceTrigerRead = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cmb_TypeDeviceTrigerRead = new System.Windows.Forms.ComboBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label25 = new System.Windows.Forms.Label();
            this.cmb_datatype1 = new System.Windows.Forms.ComboBox();
            this.txb_lenghtdevicedata1 = new System.Windows.Forms.TextBox();
            this.txb_namedevicedata1 = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.cmb_typedevicedata1 = new System.Windows.Forms.ComboBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.cmb_datatype2 = new System.Windows.Forms.ComboBox();
            this.txb_lenghtdevicedata2 = new System.Windows.Forms.TextBox();
            this.txb_namedevicedata2 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.cmb_typedevicedata2 = new System.Windows.Forms.ComboBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.cmb_datatype3 = new System.Windows.Forms.ComboBox();
            this.txb_lenghtdevicedata3 = new System.Windows.Forms.TextBox();
            this.txb_namedevicedata3 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.cmb_typedevicedata3 = new System.Windows.Forms.ComboBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label17 = new System.Windows.Forms.Label();
            this.cmb_datatype4 = new System.Windows.Forms.ComboBox();
            this.txb_lenghtdevicedata4 = new System.Windows.Forms.TextBox();
            this.txb_namedevicedata4 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.cmb_typedevicedata4 = new System.Windows.Forms.ComboBox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label27 = new System.Windows.Forms.Label();
            this.cmb_datatype5 = new System.Windows.Forms.ComboBox();
            this.txb_lenghtdevicedata5 = new System.Windows.Forms.TextBox();
            this.txb_namedevicedata5 = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.cmb_typedevicedata5 = new System.Windows.Forms.ComboBox();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label32 = new System.Windows.Forms.Label();
            this.cmb_datatype6 = new System.Windows.Forms.ComboBox();
            this.txb_lenghtdevicedata6 = new System.Windows.Forms.TextBox();
            this.txb_namedevicedata6 = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.cmb_typedevicedata6 = new System.Windows.Forms.ComboBox();
            this.panel9 = new System.Windows.Forms.Panel();
            this.label37 = new System.Windows.Forms.Label();
            this.cmb_datatype7 = new System.Windows.Forms.ComboBox();
            this.txb_lenghtdevicedata7 = new System.Windows.Forms.TextBox();
            this.txb_namedevicedata7 = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.cmb_typedevicedata7 = new System.Windows.Forms.ComboBox();
            this.panel10 = new System.Windows.Forms.Panel();
            this.txb_NameDeviceTrigerReadComplete = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.cmb_TypeDeviceTrigerReadComplete = new System.Windows.Forms.ComboBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtg_dataconfig)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel10.SuspendLayout();
            this.SuspendLayout();
            // 
            // txb_namefunction
            // 
            this.txb_namefunction.Location = new System.Drawing.Point(122, 8);
            this.txb_namefunction.Margin = new System.Windows.Forms.Padding(4);
            this.txb_namefunction.Name = "txb_namefunction";
            this.txb_namefunction.Size = new System.Drawing.Size(276, 22);
            this.txb_namefunction.TabIndex = 2;
            // 
            // txb_ipaddress
            // 
            this.txb_ipaddress.Location = new System.Drawing.Point(497, 9);
            this.txb_ipaddress.Margin = new System.Windows.Forms.Padding(4);
            this.txb_ipaddress.Name = "txb_ipaddress";
            this.txb_ipaddress.Size = new System.Drawing.Size(175, 22);
            this.txb_ipaddress.TabIndex = 3;
            // 
            // txb_portnumber
            // 
            this.txb_portnumber.Location = new System.Drawing.Point(777, 8);
            this.txb_portnumber.Margin = new System.Windows.Forms.Padding(4);
            this.txb_portnumber.Name = "txb_portnumber";
            this.txb_portnumber.Size = new System.Drawing.Size(120, 22);
            this.txb_portnumber.TabIndex = 4;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.btn_add);
            this.panel1.Controls.Add(this.label24);
            this.panel1.Controls.Add(this.label23);
            this.panel1.Controls.Add(this.label22);
            this.panel1.Controls.Add(this.txb_portnumber);
            this.panel1.Controls.Add(this.btn_update);
            this.panel1.Controls.Add(this.txb_ipaddress);
            this.panel1.Controls.Add(this.txb_namefunction);
            this.panel1.Location = new System.Drawing.Point(7, 7);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1246, 41);
            this.panel1.TabIndex = 5;
            // 
            // btn_add
            // 
            this.btn_add.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_add.Location = new System.Drawing.Point(1050, 5);
            this.btn_add.Margin = new System.Windows.Forms.Padding(4);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(88, 31);
            this.btn_add.TabIndex = 10;
            this.btn_add.Text = "Add";
            this.btn_add.UseVisualStyleBackColor = true;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click_1);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(680, 12);
            this.label24.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(93, 16);
            this.label24.TabIndex = 8;
            this.label24.Text = "Port Number";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(419, 12);
            this.label23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(78, 16);
            this.label23.TabIndex = 7;
            this.label23.Text = "IPaddress";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(7, 11);
            this.label22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(110, 16);
            this.label22.TabIndex = 6;
            this.label22.Text = "Name Function";
            // 
            // btn_update
            // 
            this.btn_update.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_update.Location = new System.Drawing.Point(1146, 5);
            this.btn_update.Margin = new System.Windows.Forms.Padding(4);
            this.btn_update.Name = "btn_update";
            this.btn_update.Size = new System.Drawing.Size(88, 31);
            this.btn_update.TabIndex = 9;
            this.btn_update.Text = "Update";
            this.btn_update.UseVisualStyleBackColor = true;
            this.btn_update.Click += new System.EventHandler(this.btn_update_Click);
            // 
            // dtg_dataconfig
            // 
            this.dtg_dataconfig.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dtg_dataconfig.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtg_dataconfig.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtg_dataconfig.Location = new System.Drawing.Point(7, 298);
            this.dtg_dataconfig.MultiSelect = false;
            this.dtg_dataconfig.Name = "dtg_dataconfig";
            this.dtg_dataconfig.ReadOnly = true;
            this.dtg_dataconfig.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtg_dataconfig.Size = new System.Drawing.Size(1246, 402);
            this.dtg_dataconfig.TabIndex = 17;
            this.dtg_dataconfig.SelectionChanged += new System.EventHandler(this.dtg_dataconfig_SelectionChanged_1);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.txb_NameDeviceTrigerRead);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.cmb_TypeDeviceTrigerRead);
            this.panel2.Location = new System.Drawing.Point(7, 55);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(356, 66);
            this.panel2.TabIndex = 15;
            // 
            // txb_NameDeviceTrigerRead
            // 
            this.txb_NameDeviceTrigerRead.Location = new System.Drawing.Point(273, 34);
            this.txb_NameDeviceTrigerRead.Name = "txb_NameDeviceTrigerRead";
            this.txb_NameDeviceTrigerRead.Size = new System.Drawing.Size(61, 22);
            this.txb_NameDeviceTrigerRead.TabIndex = 8;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(167, 38);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(90, 16);
            this.label12.TabIndex = 7;
            this.label12.Text = "Name Device";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(98, 6);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(83, 15);
            this.label7.TabIndex = 6;
            this.label7.Text = "Triger Read";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 36);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Type Device";
            // 
            // cmb_TypeDeviceTrigerRead
            // 
            this.cmb_TypeDeviceTrigerRead.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_TypeDeviceTrigerRead.FormattingEnabled = true;
            this.cmb_TypeDeviceTrigerRead.Items.AddRange(new object[] {
            "",
            "M",
            "L",
            "B"});
            this.cmb_TypeDeviceTrigerRead.Location = new System.Drawing.Point(95, 32);
            this.cmb_TypeDeviceTrigerRead.Name = "cmb_TypeDeviceTrigerRead";
            this.cmb_TypeDeviceTrigerRead.Size = new System.Drawing.Size(63, 24);
            this.cmb_TypeDeviceTrigerRead.TabIndex = 0;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.label25);
            this.panel4.Controls.Add(this.cmb_datatype1);
            this.panel4.Controls.Add(this.txb_lenghtdevicedata1);
            this.panel4.Controls.Add(this.txb_namedevicedata1);
            this.panel4.Controls.Add(this.label20);
            this.panel4.Controls.Add(this.label8);
            this.panel4.Controls.Add(this.label9);
            this.panel4.Controls.Add(this.label10);
            this.panel4.Controls.Add(this.cmb_typedevicedata1);
            this.panel4.Location = new System.Drawing.Point(10, 127);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(170, 165);
            this.panel4.TabIndex = 18;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(0, 133);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(85, 16);
            this.label25.TabIndex = 14;
            this.label25.Text = "Type Device";
            // 
            // cmb_datatype1
            // 
            this.cmb_datatype1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_datatype1.FormattingEnabled = true;
            this.cmb_datatype1.Items.AddRange(new object[] {
            "",
            "String",
            "DEC",
            "Float"});
            this.cmb_datatype1.Location = new System.Drawing.Point(96, 126);
            this.cmb_datatype1.Name = "cmb_datatype1";
            this.cmb_datatype1.Size = new System.Drawing.Size(63, 24);
            this.cmb_datatype1.TabIndex = 13;
            this.cmb_datatype1.SelectedIndexChanged += new System.EventHandler(this.cmb_datatype1_SelectedIndexChanged);
            // 
            // txb_lenghtdevicedata1
            // 
            this.txb_lenghtdevicedata1.Location = new System.Drawing.Point(97, 96);
            this.txb_lenghtdevicedata1.Name = "txb_lenghtdevicedata1";
            this.txb_lenghtdevicedata1.Size = new System.Drawing.Size(61, 22);
            this.txb_lenghtdevicedata1.TabIndex = 12;
            // 
            // txb_namedevicedata1
            // 
            this.txb_namedevicedata1.Location = new System.Drawing.Point(97, 59);
            this.txb_namedevicedata1.Name = "txb_namedevicedata1";
            this.txb_namedevicedata1.Size = new System.Drawing.Size(61, 22);
            this.txb_namedevicedata1.TabIndex = 11;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(0, 99);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(93, 16);
            this.label20.TabIndex = 11;
            this.label20.Text = "Length Device";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(1, 61);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(90, 16);
            this.label8.TabIndex = 7;
            this.label8.Text = "Name Device";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(50, 5);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(45, 15);
            this.label9.TabIndex = 6;
            this.label9.Text = "Data1";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(1, 27);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(85, 16);
            this.label10.TabIndex = 1;
            this.label10.Text = "Type Device";
            // 
            // cmb_typedevicedata1
            // 
            this.cmb_typedevicedata1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_typedevicedata1.FormattingEnabled = true;
            this.cmb_typedevicedata1.Items.AddRange(new object[] {
            "",
            "D",
            "ZR"});
            this.cmb_typedevicedata1.Location = new System.Drawing.Point(97, 23);
            this.cmb_typedevicedata1.Name = "cmb_typedevicedata1";
            this.cmb_typedevicedata1.Size = new System.Drawing.Size(63, 24);
            this.cmb_typedevicedata1.TabIndex = 0;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this.cmb_datatype2);
            this.panel3.Controls.Add(this.txb_lenghtdevicedata2);
            this.panel3.Controls.Add(this.txb_namedevicedata2);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Controls.Add(this.cmb_typedevicedata2);
            this.panel3.Location = new System.Drawing.Point(193, 127);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(170, 165);
            this.panel3.TabIndex = 19;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(0, 133);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 16);
            this.label1.TabIndex = 14;
            this.label1.Text = "Type Device";
            // 
            // cmb_datatype2
            // 
            this.cmb_datatype2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_datatype2.FormattingEnabled = true;
            this.cmb_datatype2.Items.AddRange(new object[] {
            "",
            "String",
            "DEC",
            "Float"});
            this.cmb_datatype2.Location = new System.Drawing.Point(96, 126);
            this.cmb_datatype2.Name = "cmb_datatype2";
            this.cmb_datatype2.Size = new System.Drawing.Size(63, 24);
            this.cmb_datatype2.TabIndex = 13;
            this.cmb_datatype2.SelectedIndexChanged += new System.EventHandler(this.cmb_datatype2_SelectedIndexChanged);
            // 
            // txb_lenghtdevicedata2
            // 
            this.txb_lenghtdevicedata2.Location = new System.Drawing.Point(97, 96);
            this.txb_lenghtdevicedata2.Name = "txb_lenghtdevicedata2";
            this.txb_lenghtdevicedata2.Size = new System.Drawing.Size(61, 22);
            this.txb_lenghtdevicedata2.TabIndex = 12;
            // 
            // txb_namedevicedata2
            // 
            this.txb_namedevicedata2.Location = new System.Drawing.Point(97, 59);
            this.txb_namedevicedata2.Name = "txb_namedevicedata2";
            this.txb_namedevicedata2.Size = new System.Drawing.Size(61, 22);
            this.txb_namedevicedata2.TabIndex = 11;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(0, 99);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(93, 16);
            this.label3.TabIndex = 11;
            this.label3.Text = "Length Device";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(1, 61);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(90, 16);
            this.label4.TabIndex = 7;
            this.label4.Text = "Name Device";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(50, 5);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(45, 15);
            this.label5.TabIndex = 6;
            this.label5.Text = "Data2";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(1, 27);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(85, 16);
            this.label6.TabIndex = 1;
            this.label6.Text = "Type Device";
            // 
            // cmb_typedevicedata2
            // 
            this.cmb_typedevicedata2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_typedevicedata2.FormattingEnabled = true;
            this.cmb_typedevicedata2.Items.AddRange(new object[] {
            "",
            "D",
            "ZR"});
            this.cmb_typedevicedata2.Location = new System.Drawing.Point(97, 23);
            this.cmb_typedevicedata2.Name = "cmb_typedevicedata2";
            this.cmb_typedevicedata2.Size = new System.Drawing.Size(63, 24);
            this.cmb_typedevicedata2.TabIndex = 0;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.label11);
            this.panel5.Controls.Add(this.cmb_datatype3);
            this.panel5.Controls.Add(this.txb_lenghtdevicedata3);
            this.panel5.Controls.Add(this.txb_namedevicedata3);
            this.panel5.Controls.Add(this.label13);
            this.panel5.Controls.Add(this.label14);
            this.panel5.Controls.Add(this.label15);
            this.panel5.Controls.Add(this.label16);
            this.panel5.Controls.Add(this.cmb_typedevicedata3);
            this.panel5.Location = new System.Drawing.Point(376, 127);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(170, 165);
            this.panel5.TabIndex = 19;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(0, 133);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(85, 16);
            this.label11.TabIndex = 14;
            this.label11.Text = "Type Device";
            // 
            // cmb_datatype3
            // 
            this.cmb_datatype3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_datatype3.FormattingEnabled = true;
            this.cmb_datatype3.Items.AddRange(new object[] {
            "",
            "String",
            "DEC",
            "Float"});
            this.cmb_datatype3.Location = new System.Drawing.Point(96, 126);
            this.cmb_datatype3.Name = "cmb_datatype3";
            this.cmb_datatype3.Size = new System.Drawing.Size(63, 24);
            this.cmb_datatype3.TabIndex = 13;
            this.cmb_datatype3.SelectedIndexChanged += new System.EventHandler(this.cmb_datatype3_SelectedIndexChanged);
            // 
            // txb_lenghtdevicedata3
            // 
            this.txb_lenghtdevicedata3.Location = new System.Drawing.Point(97, 96);
            this.txb_lenghtdevicedata3.Name = "txb_lenghtdevicedata3";
            this.txb_lenghtdevicedata3.Size = new System.Drawing.Size(61, 22);
            this.txb_lenghtdevicedata3.TabIndex = 12;
            // 
            // txb_namedevicedata3
            // 
            this.txb_namedevicedata3.Location = new System.Drawing.Point(97, 59);
            this.txb_namedevicedata3.Name = "txb_namedevicedata3";
            this.txb_namedevicedata3.Size = new System.Drawing.Size(61, 22);
            this.txb_namedevicedata3.TabIndex = 11;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(0, 99);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(93, 16);
            this.label13.TabIndex = 11;
            this.label13.Text = "Length Device";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(1, 61);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(90, 16);
            this.label14.TabIndex = 7;
            this.label14.Text = "Name Device";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(50, 5);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(45, 15);
            this.label15.TabIndex = 6;
            this.label15.Text = "Data3";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(1, 27);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(85, 16);
            this.label16.TabIndex = 1;
            this.label16.Text = "Type Device";
            // 
            // cmb_typedevicedata3
            // 
            this.cmb_typedevicedata3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_typedevicedata3.FormattingEnabled = true;
            this.cmb_typedevicedata3.Items.AddRange(new object[] {
            "",
            "D",
            "ZR"});
            this.cmb_typedevicedata3.Location = new System.Drawing.Point(97, 23);
            this.cmb_typedevicedata3.Name = "cmb_typedevicedata3";
            this.cmb_typedevicedata3.Size = new System.Drawing.Size(63, 24);
            this.cmb_typedevicedata3.TabIndex = 0;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.Controls.Add(this.label17);
            this.panel6.Controls.Add(this.cmb_datatype4);
            this.panel6.Controls.Add(this.txb_lenghtdevicedata4);
            this.panel6.Controls.Add(this.txb_namedevicedata4);
            this.panel6.Controls.Add(this.label18);
            this.panel6.Controls.Add(this.label19);
            this.panel6.Controls.Add(this.label21);
            this.panel6.Controls.Add(this.label26);
            this.panel6.Controls.Add(this.cmb_typedevicedata4);
            this.panel6.Location = new System.Drawing.Point(552, 127);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(170, 165);
            this.panel6.TabIndex = 19;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(0, 133);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(85, 16);
            this.label17.TabIndex = 14;
            this.label17.Text = "Type Device";
            // 
            // cmb_datatype4
            // 
            this.cmb_datatype4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_datatype4.FormattingEnabled = true;
            this.cmb_datatype4.Items.AddRange(new object[] {
            "",
            "String",
            "DEC",
            "Float"});
            this.cmb_datatype4.Location = new System.Drawing.Point(96, 126);
            this.cmb_datatype4.Name = "cmb_datatype4";
            this.cmb_datatype4.Size = new System.Drawing.Size(63, 24);
            this.cmb_datatype4.TabIndex = 13;
            this.cmb_datatype4.SelectedIndexChanged += new System.EventHandler(this.cmb_datatype4_SelectedIndexChanged);
            // 
            // txb_lenghtdevicedata4
            // 
            this.txb_lenghtdevicedata4.Location = new System.Drawing.Point(97, 96);
            this.txb_lenghtdevicedata4.Name = "txb_lenghtdevicedata4";
            this.txb_lenghtdevicedata4.Size = new System.Drawing.Size(61, 22);
            this.txb_lenghtdevicedata4.TabIndex = 12;
            // 
            // txb_namedevicedata4
            // 
            this.txb_namedevicedata4.Location = new System.Drawing.Point(97, 59);
            this.txb_namedevicedata4.Name = "txb_namedevicedata4";
            this.txb_namedevicedata4.Size = new System.Drawing.Size(61, 22);
            this.txb_namedevicedata4.TabIndex = 11;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(0, 99);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(93, 16);
            this.label18.TabIndex = 11;
            this.label18.Text = "Length Device";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(1, 61);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(90, 16);
            this.label19.TabIndex = 7;
            this.label19.Text = "Name Device";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(50, 5);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(45, 15);
            this.label21.TabIndex = 6;
            this.label21.Text = "Data4";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(1, 27);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(85, 16);
            this.label26.TabIndex = 1;
            this.label26.Text = "Type Device";
            // 
            // cmb_typedevicedata4
            // 
            this.cmb_typedevicedata4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_typedevicedata4.FormattingEnabled = true;
            this.cmb_typedevicedata4.Items.AddRange(new object[] {
            "",
            "D",
            "ZR"});
            this.cmb_typedevicedata4.Location = new System.Drawing.Point(97, 23);
            this.cmb_typedevicedata4.Name = "cmb_typedevicedata4";
            this.cmb_typedevicedata4.Size = new System.Drawing.Size(63, 24);
            this.cmb_typedevicedata4.TabIndex = 0;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel7.Controls.Add(this.label27);
            this.panel7.Controls.Add(this.cmb_datatype5);
            this.panel7.Controls.Add(this.txb_lenghtdevicedata5);
            this.panel7.Controls.Add(this.txb_namedevicedata5);
            this.panel7.Controls.Add(this.label28);
            this.panel7.Controls.Add(this.label29);
            this.panel7.Controls.Add(this.label30);
            this.panel7.Controls.Add(this.label31);
            this.panel7.Controls.Add(this.cmb_typedevicedata5);
            this.panel7.Location = new System.Drawing.Point(728, 127);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(170, 165);
            this.panel7.TabIndex = 19;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(0, 133);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(85, 16);
            this.label27.TabIndex = 14;
            this.label27.Text = "Type Device";
            // 
            // cmb_datatype5
            // 
            this.cmb_datatype5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_datatype5.FormattingEnabled = true;
            this.cmb_datatype5.Items.AddRange(new object[] {
            "",
            "String",
            "DEC",
            "Float"});
            this.cmb_datatype5.Location = new System.Drawing.Point(96, 126);
            this.cmb_datatype5.Name = "cmb_datatype5";
            this.cmb_datatype5.Size = new System.Drawing.Size(63, 24);
            this.cmb_datatype5.TabIndex = 13;
            this.cmb_datatype5.SelectedIndexChanged += new System.EventHandler(this.cmb_datatype5_SelectedIndexChanged);
            // 
            // txb_lenghtdevicedata5
            // 
            this.txb_lenghtdevicedata5.Location = new System.Drawing.Point(97, 96);
            this.txb_lenghtdevicedata5.Name = "txb_lenghtdevicedata5";
            this.txb_lenghtdevicedata5.Size = new System.Drawing.Size(61, 22);
            this.txb_lenghtdevicedata5.TabIndex = 12;
            // 
            // txb_namedevicedata5
            // 
            this.txb_namedevicedata5.Location = new System.Drawing.Point(97, 59);
            this.txb_namedevicedata5.Name = "txb_namedevicedata5";
            this.txb_namedevicedata5.Size = new System.Drawing.Size(61, 22);
            this.txb_namedevicedata5.TabIndex = 11;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(0, 99);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(93, 16);
            this.label28.TabIndex = 11;
            this.label28.Text = "Length Device";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(1, 61);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(90, 16);
            this.label29.TabIndex = 7;
            this.label29.Text = "Name Device";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(50, 5);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(45, 15);
            this.label30.TabIndex = 6;
            this.label30.Text = "Data5";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(1, 27);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(85, 16);
            this.label31.TabIndex = 1;
            this.label31.Text = "Type Device";
            // 
            // cmb_typedevicedata5
            // 
            this.cmb_typedevicedata5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_typedevicedata5.FormattingEnabled = true;
            this.cmb_typedevicedata5.Items.AddRange(new object[] {
            "",
            "D",
            "ZR"});
            this.cmb_typedevicedata5.Location = new System.Drawing.Point(97, 23);
            this.cmb_typedevicedata5.Name = "cmb_typedevicedata5";
            this.cmb_typedevicedata5.Size = new System.Drawing.Size(63, 24);
            this.cmb_typedevicedata5.TabIndex = 0;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel8.Controls.Add(this.label32);
            this.panel8.Controls.Add(this.cmb_datatype6);
            this.panel8.Controls.Add(this.txb_lenghtdevicedata6);
            this.panel8.Controls.Add(this.txb_namedevicedata6);
            this.panel8.Controls.Add(this.label33);
            this.panel8.Controls.Add(this.label34);
            this.panel8.Controls.Add(this.label35);
            this.panel8.Controls.Add(this.label36);
            this.panel8.Controls.Add(this.cmb_typedevicedata6);
            this.panel8.Location = new System.Drawing.Point(904, 127);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(170, 165);
            this.panel8.TabIndex = 19;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(0, 133);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(85, 16);
            this.label32.TabIndex = 14;
            this.label32.Text = "Type Device";
            // 
            // cmb_datatype6
            // 
            this.cmb_datatype6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_datatype6.FormattingEnabled = true;
            this.cmb_datatype6.Items.AddRange(new object[] {
            "",
            "String",
            "DEC",
            "Float"});
            this.cmb_datatype6.Location = new System.Drawing.Point(96, 126);
            this.cmb_datatype6.Name = "cmb_datatype6";
            this.cmb_datatype6.Size = new System.Drawing.Size(63, 24);
            this.cmb_datatype6.TabIndex = 13;
            this.cmb_datatype6.SelectedIndexChanged += new System.EventHandler(this.cmb_datatype6_SelectedIndexChanged);
            // 
            // txb_lenghtdevicedata6
            // 
            this.txb_lenghtdevicedata6.Location = new System.Drawing.Point(97, 96);
            this.txb_lenghtdevicedata6.Name = "txb_lenghtdevicedata6";
            this.txb_lenghtdevicedata6.Size = new System.Drawing.Size(61, 22);
            this.txb_lenghtdevicedata6.TabIndex = 12;
            // 
            // txb_namedevicedata6
            // 
            this.txb_namedevicedata6.Location = new System.Drawing.Point(97, 59);
            this.txb_namedevicedata6.Name = "txb_namedevicedata6";
            this.txb_namedevicedata6.Size = new System.Drawing.Size(61, 22);
            this.txb_namedevicedata6.TabIndex = 11;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(0, 99);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(93, 16);
            this.label33.TabIndex = 11;
            this.label33.Text = "Length Device";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(1, 61);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(90, 16);
            this.label34.TabIndex = 7;
            this.label34.Text = "Name Device";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(50, 5);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(45, 15);
            this.label35.TabIndex = 6;
            this.label35.Text = "Data6";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(1, 27);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(85, 16);
            this.label36.TabIndex = 1;
            this.label36.Text = "Type Device";
            // 
            // cmb_typedevicedata6
            // 
            this.cmb_typedevicedata6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_typedevicedata6.FormattingEnabled = true;
            this.cmb_typedevicedata6.Items.AddRange(new object[] {
            "",
            "D",
            "ZR"});
            this.cmb_typedevicedata6.Location = new System.Drawing.Point(97, 23);
            this.cmb_typedevicedata6.Name = "cmb_typedevicedata6";
            this.cmb_typedevicedata6.Size = new System.Drawing.Size(63, 24);
            this.cmb_typedevicedata6.TabIndex = 0;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panel9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel9.Controls.Add(this.label37);
            this.panel9.Controls.Add(this.cmb_datatype7);
            this.panel9.Controls.Add(this.txb_lenghtdevicedata7);
            this.panel9.Controls.Add(this.txb_namedevicedata7);
            this.panel9.Controls.Add(this.label38);
            this.panel9.Controls.Add(this.label39);
            this.panel9.Controls.Add(this.label40);
            this.panel9.Controls.Add(this.label41);
            this.panel9.Controls.Add(this.cmb_typedevicedata7);
            this.panel9.Location = new System.Drawing.Point(1083, 127);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(170, 165);
            this.panel9.TabIndex = 19;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(0, 133);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(85, 16);
            this.label37.TabIndex = 14;
            this.label37.Text = "Type Device";
            // 
            // cmb_datatype7
            // 
            this.cmb_datatype7.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_datatype7.FormattingEnabled = true;
            this.cmb_datatype7.Items.AddRange(new object[] {
            "",
            "String",
            "DEC",
            "Float"});
            this.cmb_datatype7.Location = new System.Drawing.Point(96, 126);
            this.cmb_datatype7.Name = "cmb_datatype7";
            this.cmb_datatype7.Size = new System.Drawing.Size(63, 24);
            this.cmb_datatype7.TabIndex = 13;
            this.cmb_datatype7.SelectedIndexChanged += new System.EventHandler(this.cmb_datatype7_SelectedIndexChanged);
            // 
            // txb_lenghtdevicedata7
            // 
            this.txb_lenghtdevicedata7.Location = new System.Drawing.Point(97, 96);
            this.txb_lenghtdevicedata7.Name = "txb_lenghtdevicedata7";
            this.txb_lenghtdevicedata7.Size = new System.Drawing.Size(61, 22);
            this.txb_lenghtdevicedata7.TabIndex = 12;
            // 
            // txb_namedevicedata7
            // 
            this.txb_namedevicedata7.Location = new System.Drawing.Point(97, 59);
            this.txb_namedevicedata7.Name = "txb_namedevicedata7";
            this.txb_namedevicedata7.Size = new System.Drawing.Size(61, 22);
            this.txb_namedevicedata7.TabIndex = 11;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(0, 99);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(93, 16);
            this.label38.TabIndex = 11;
            this.label38.Text = "Length Device";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(1, 61);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(90, 16);
            this.label39.TabIndex = 7;
            this.label39.Text = "Name Device";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(50, 5);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(45, 15);
            this.label40.TabIndex = 6;
            this.label40.Text = "Data7";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(1, 27);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(85, 16);
            this.label41.TabIndex = 1;
            this.label41.Text = "Type Device";
            // 
            // cmb_typedevicedata7
            // 
            this.cmb_typedevicedata7.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_typedevicedata7.FormattingEnabled = true;
            this.cmb_typedevicedata7.Items.AddRange(new object[] {
            "",
            "D",
            "ZR"});
            this.cmb_typedevicedata7.Location = new System.Drawing.Point(97, 23);
            this.cmb_typedevicedata7.Name = "cmb_typedevicedata7";
            this.cmb_typedevicedata7.Size = new System.Drawing.Size(63, 24);
            this.cmb_typedevicedata7.TabIndex = 0;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.Cyan;
            this.panel10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel10.Controls.Add(this.txb_NameDeviceTrigerReadComplete);
            this.panel10.Controls.Add(this.label42);
            this.panel10.Controls.Add(this.label43);
            this.panel10.Controls.Add(this.label44);
            this.panel10.Controls.Add(this.cmb_TypeDeviceTrigerReadComplete);
            this.panel10.Location = new System.Drawing.Point(376, 56);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(346, 66);
            this.panel10.TabIndex = 16;
            // 
            // txb_NameDeviceTrigerReadComplete
            // 
            this.txb_NameDeviceTrigerReadComplete.Location = new System.Drawing.Point(273, 34);
            this.txb_NameDeviceTrigerReadComplete.Name = "txb_NameDeviceTrigerReadComplete";
            this.txb_NameDeviceTrigerReadComplete.Size = new System.Drawing.Size(61, 22);
            this.txb_NameDeviceTrigerReadComplete.TabIndex = 8;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(167, 38);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(90, 16);
            this.label42.TabIndex = 7;
            this.label42.Text = "Name Device";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(101, 6);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(148, 15);
            this.label43.TabIndex = 6;
            this.label43.Text = "Triger Read Complete";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(6, 36);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(85, 16);
            this.label44.TabIndex = 1;
            this.label44.Text = "Type Device";
            // 
            // cmb_TypeDeviceTrigerReadComplete
            // 
            this.cmb_TypeDeviceTrigerReadComplete.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_TypeDeviceTrigerReadComplete.FormattingEnabled = true;
            this.cmb_TypeDeviceTrigerReadComplete.Items.AddRange(new object[] {
            "",
            "M",
            "L",
            "B"});
            this.cmb_TypeDeviceTrigerReadComplete.Location = new System.Drawing.Point(95, 32);
            this.cmb_TypeDeviceTrigerReadComplete.Name = "cmb_TypeDeviceTrigerReadComplete";
            this.cmb_TypeDeviceTrigerReadComplete.Size = new System.Drawing.Size(63, 24);
            this.cmb_TypeDeviceTrigerReadComplete.TabIndex = 0;
            // 
            // SetupGetData
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1261, 707);
            this.Controls.Add(this.panel10);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.dtg_dataconfig);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "SetupGetData";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SetupGetData";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtg_dataconfig)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TextBox txb_namefunction;
        private System.Windows.Forms.TextBox txb_ipaddress;
        private System.Windows.Forms.TextBox txb_portnumber;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btn_update;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txb_NameDeviceTrigerRead;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmb_TypeDeviceTrigerRead;
        private System.Windows.Forms.DataGridView dtg_dataconfig;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.ComboBox cmb_datatype1;
        private System.Windows.Forms.TextBox txb_lenghtdevicedata1;
        private System.Windows.Forms.TextBox txb_namedevicedata1;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox cmb_typedevicedata1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmb_datatype2;
        private System.Windows.Forms.TextBox txb_lenghtdevicedata2;
        private System.Windows.Forms.TextBox txb_namedevicedata2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cmb_typedevicedata2;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox cmb_datatype3;
        private System.Windows.Forms.TextBox txb_lenghtdevicedata3;
        private System.Windows.Forms.TextBox txb_namedevicedata3;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ComboBox cmb_typedevicedata3;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ComboBox cmb_datatype4;
        private System.Windows.Forms.TextBox txb_lenghtdevicedata4;
        private System.Windows.Forms.TextBox txb_namedevicedata4;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.ComboBox cmb_typedevicedata4;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.ComboBox cmb_datatype5;
        private System.Windows.Forms.TextBox txb_lenghtdevicedata5;
        private System.Windows.Forms.TextBox txb_namedevicedata5;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.ComboBox cmb_typedevicedata5;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.ComboBox cmb_datatype6;
        private System.Windows.Forms.TextBox txb_lenghtdevicedata6;
        private System.Windows.Forms.TextBox txb_namedevicedata6;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.ComboBox cmb_typedevicedata6;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.ComboBox cmb_datatype7;
        private System.Windows.Forms.TextBox txb_lenghtdevicedata7;
        private System.Windows.Forms.TextBox txb_namedevicedata7;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.ComboBox cmb_typedevicedata7;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.TextBox txb_NameDeviceTrigerReadComplete;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.ComboBox cmb_TypeDeviceTrigerReadComplete;
    }
}